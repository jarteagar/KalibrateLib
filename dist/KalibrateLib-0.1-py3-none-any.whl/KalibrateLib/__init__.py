from .modulo1 import mi_funcion

def OSVersion():
    det = f"Version 1.0 =============
            Libreria para agilizar el uso de las api de kalibrate
            USO:
            "
    return det