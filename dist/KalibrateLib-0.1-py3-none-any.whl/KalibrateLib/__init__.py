from .funciones import getToken

def OSVersion():
    det = """Version 1.0 =============
    Libreria para agilizar el uso de las api de kalibrate
    USO:
    """
    return det
