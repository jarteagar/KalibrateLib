from .funciones import getToken

def OSVersion():
    det = """Version 1.4 =============
    Libreria para agilizar el uso de las api de kalibrate
    USO:
    Consultar con John Arteaga

    getColumnsSite _____
    regresa 3 arreglos:
        SiteInfo : data principal del site
        CompetitorSites : informacion sobre 'competitor site' 
        SiteGroupings : informacion sobre 'site grouping'
    """
    return det
