from .funciones import getToken

def OSVersion():
    det = """Version 1.2 =============
    Libreria para agilizar el uso de las api de kalibrate
    USO:
    Consultar con John Arteaga
    """
    return det
